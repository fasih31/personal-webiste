export const contactsData = {
    email: 'fasih31@gmail.com, info@fasih.com.pk',
    phone: '+923362609333',
    address: 'International City, Dubai, United Arab Emirates ',

    sheetAPI: ''
}