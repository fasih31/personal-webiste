export const educationData = [
    {
        id: 3,
        institution: 'Ilma Univetsity',
        course: 'Bachelors of Science - Computer Science',
        startYear: '2015',
        endYear: '2019'
    },
    {
        id: 2,
        institution: 'Government National College',
        course: 'Intermediate',
        startYear: '2012',
        endYear: '2014'
    },
    {
        id: 1,
        institution: 'Al Kamran Public School',
        course: 'Matriculation',
        startYear: '2008',
        endYear: '2010'
    },
]