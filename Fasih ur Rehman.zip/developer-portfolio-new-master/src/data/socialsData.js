export const socialsData = {
    github: 'https://github.com/fasih31/',
    facebook: 'https://www.facebook.com/fasihurrehman05/',
    linkedIn: 'https://www.linkedin.com/in/fasihurrehman05/',
    instagram: 'https://www.instagram.com/',
    codepen: 'https://codepen.io/Fasihurrehman',
    twitter: 'https://twitter.com/@fasih31',
    reddit: 'https://www.reddit.com/',
    blogger: 'https://www.blogger.com/',
    medium: 'https://medium.com/@fasih31',
    stackOverflow: 'https://stackoverflow.com/',
    gitlab: 'https://gitlab.com/fasihurrehman',
    youtube: 'https://www.youtube.com/@techpreneurr/'
}