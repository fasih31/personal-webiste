export const experienceData = [
    {
        id: 1,
        company: 'Greens Fin Innovations Pvt Ltd',
        jobtitle: 'Product Manager',
        //products: 'BNPL, Advance Salary, Business Financing, SME Commercial Products, Bonds, Investment and other Fintech Products',
        startYear: 'September 2021',
        endYear: 'Present'
    },
    {
        id: 2,
        company: 'Imarkplace (Pvt) Ltd.',
        jobtitle: 'Techincal Project Manager',
        startYear: '2019',
        endYear: 'July 2023'
    },
    {
        id: 3,
        company: 'Usmani and Co (Pvt) Ltd.',
        jobtitle: 'Project Manager',
        startYear: '2019',
        endYear: 'June 2023'
    },
    {
        id: 4,
        company: 'Centre For Islamic Economics',
        jobtitle: 'Project Manager',
        startYear: '2018',
        endYear: 'June 2023'
    },

    {
        id: 5,
        company: 'A.A. Joyland (Pvt) Ltd',
        jobtitle: 'Assistant Company Secretary',
        startYear: '2013',
        endYear: '2017'
    },
    {
        id: 6,
        company: 'The Viable Squad',
        jobtitle: 'Sr. Product Development Manager',
        startYear: '2014',
        endYear: '2018'

    },
]