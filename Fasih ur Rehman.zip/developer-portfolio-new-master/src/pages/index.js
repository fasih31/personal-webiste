export { default as Main } from './Main/Main'
export { default as BlogPage } from './Blog/BlogPage'
export { default as ProjectPage } from './Project/ProjectPage'